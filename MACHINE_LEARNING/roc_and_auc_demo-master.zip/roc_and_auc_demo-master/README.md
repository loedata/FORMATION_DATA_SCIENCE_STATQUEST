This is the code from
* ROC and AUC in R: https://youtu.be/qcvAqAH60Yw
